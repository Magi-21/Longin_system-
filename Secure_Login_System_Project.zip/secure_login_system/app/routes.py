import re
import io
import base64
import pyotp
import qrcode
from flask import Blueprint, render_template, request, redirect, url_for, flash, session, abort
from flask_bcrypt import generate_password_hash, check_password_hash
from sqlalchemy import or_

from . import db
from .models import User

main = Blueprint("main", __name__)

USERNAME_RE = re.compile(r"^[A-Za-z0-9_]{3,30}$")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

def get_current_user():
    user_id = session.get("user_id")
    if not user_id:
        return None
    return db.session.get(User, user_id)

def password_is_strong(password):
    if len(password) < 8:
        return False
    return (
        re.search(r"[A-Z]", password)
        and re.search(r"[a-z]", password)
        and re.search(r"\d", password)
    )

@main.route("/")
def index():
    user = get_current_user()
    return render_template("index.html", user=user)

@main.route("/register", methods=["GET", "POST"])
def register():
    if get_current_user():
        return redirect(url_for("main.dashboard"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm_password", "")

        if not USERNAME_RE.fullmatch(username):
            flash("Username must be 3–30 characters using letters, numbers, or underscore.", "danger")
            return render_template("register.html")

        if not EMAIL_RE.fullmatch(email):
            flash("Please enter a valid email address.", "danger")
            return render_template("register.html")

        if not password_is_strong(password):
            flash("Password must be at least 8 characters and contain uppercase, lowercase, and a number.", "danger")
            return render_template("register.html")

        if password != confirm:
            flash("Passwords do not match.", "danger")
            return render_template("register.html")

        existing = User.query.filter(or_(User.username == username, User.email == email)).first()
        if existing:
            flash("Username or email is already registered.", "danger")
            return render_template("register.html")

        user = User(
            username=username,
            email=email,
            password_hash=generate_password_hash(password).decode("utf-8")
        )
        db.session.add(user)
        db.session.commit()

        flash("Registration successful. Please log in.", "success")
        return redirect(url_for("main.login"))

    return render_template("register.html")

@main.route("/login", methods=["GET", "POST"])
def login():
    if get_current_user():
        return redirect(url_for("main.dashboard"))

    if request.method == "POST":
        login_id = request.form.get("login_id", "").strip()
        password = request.form.get("password", "")

        # Parameterized ORM query prevents SQL injection.
        user = User.query.filter(
            or_(User.username == login_id, User.email == login_id.lower())
        ).first()

        if not user or not check_password_hash(user.password_hash, password):
            flash("Invalid username/email or password.", "danger")
            return render_template("login.html")

        # Clear old authentication state before creating a new one.
        session.clear()

        if user.two_factor_enabled:
            session["pending_2fa_user_id"] = user.id
            return redirect(url_for("main.verify_2fa"))

        session["user_id"] = user.id
        session.permanent = True
        flash("Login successful.", "success")
        return redirect(url_for("main.dashboard"))

    return render_template("login.html")

@main.route("/verify-2fa", methods=["GET", "POST"])
def verify_2fa():
    user_id = session.get("pending_2fa_user_id")
    if not user_id:
        return redirect(url_for("main.login"))

    user = db.session.get(User, user_id)
    if not user or not user.two_factor_enabled or not user.two_factor_secret:
        session.clear()
        return redirect(url_for("main.login"))

    if request.method == "POST":
        code = request.form.get("code", "").strip().replace(" ", "")
        if re.fullmatch(r"\d{6}", code) and pyotp.TOTP(user.two_factor_secret).verify(code, valid_window=1):
            session.clear()
            session["user_id"] = user.id
            session.permanent = True
            flash("Two-factor authentication successful.", "success")
            return redirect(url_for("main.dashboard"))

        flash("Invalid verification code.", "danger")

    return render_template("verify_2fa.html")

@main.route("/dashboard")
def dashboard():
    user = get_current_user()
    if not user:
        return redirect(url_for("main.login"))
    return render_template("dashboard.html", user=user)

@main.route("/2fa", methods=["GET", "POST"])
def two_factor():
    user = get_current_user()
    if not user:
        return redirect(url_for("main.login"))

    if request.method == "POST":
        action = request.form.get("action")

        if action == "enable":
            secret = pyotp.random_base32()
            user.two_factor_secret = secret
            user.two_factor_enabled = True
            db.session.commit()
            flash("2FA enabled. Scan the QR code or enter the secret in your authenticator app.", "success")

        elif action == "disable":
            user.two_factor_enabled = False
            user.two_factor_secret = None
            db.session.commit()
            flash("2FA has been disabled.", "success")

        return redirect(url_for("main.two_factor"))

    qr_data = None
    if user.two_factor_enabled and user.two_factor_secret:
        uri = pyotp.TOTP(user.two_factor_secret).provisioning_uri(
            name=user.email,
            issuer_name="Secure Login System"
        )
        img = qrcode.make(uri)
        buffer = io.BytesIO()
        img.save(buffer, format="PNG")
        qr_data = "data:image/png;base64," + base64.b64encode(buffer.getvalue()).decode()

    return render_template("two_factor.html", user=user, qr_data=qr_data)

@main.route("/logout", methods=["POST"])
def logout():
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("main.index"))

@main.errorhandler(400)
def bad_request(error):
    return render_template("error.html", code=400, message="Bad request."), 400

@main.errorhandler(404)
def not_found(error):
    return render_template("error.html", code=404, message="Page not found."), 404
