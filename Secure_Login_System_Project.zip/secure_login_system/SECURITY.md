# Security notes

This project demonstrates common secure-login practices for an academic/student project.

Implemented:
- Bcrypt password hashing
- CSRF protection
- SQLAlchemy ORM queries
- Input validation
- HTTP-only and SameSite session cookies
- Optional TOTP 2FA
- Session clearing during authentication transitions

For a real production system, additionally consider:
- HTTPS everywhere
- Login rate limiting / temporary lockouts
- Password reset with short-lived signed tokens
- Email verification
- Security logging and monitoring
- Strong production secret management
- Database backups and access controls
