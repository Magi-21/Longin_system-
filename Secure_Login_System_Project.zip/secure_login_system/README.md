# Secure Login System

A beginner-friendly secure login web application built with **Python Flask + SQLite**.

## Features

- User registration
- Username/email login
- Bcrypt password hashing
- Password strength validation
- Input validation
- SQL injection protection through SQLAlchemy ORM
- Session-based authentication
- Logout
- CSRF protection
- Optional TOTP-based two-factor authentication (2FA)
- Responsive web UI

## Project structure

```text
secure_login_system/
├── app/
│   ├── __init__.py
│   ├── models.py
│   ├── routes.py
│   ├── templates/
│   └── static/
├── instance/
├── .env.example
├── .gitignore
├── requirements.txt
├── run.py
└── README.md
```

## Run locally

### 1. Create a virtual environment

Windows:
```bash
python -m venv venv
venv\Scripts\activate
```

Linux/macOS:
```bash
python3 -m venv venv
source venv/bin/activate
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Set a secret key

Copy `.env.example` to `.env` and set a strong `SECRET_KEY`.

For a quick local test, the built-in development fallback also works, but **do not use the default key in production**.

### 4. Start the application

```bash
python run.py
```

Open:
`http://127.0.0.1:5000`

## Testing checklist

1. Register a new account.
2. Try an invalid email.
3. Try a weak password.
4. Log in with username or email.
5. Open Dashboard without logging in — it should redirect to Login.
6. Enable 2FA from the dashboard.
7. Scan the QR code with an authenticator app.
8. Log out and log in again; the 6-digit 2FA code should be required.
9. Disable 2FA and test normal login again.

## Security notes

- Never store plain-text passwords.
- Use HTTPS in production.
- Set a long random `SECRET_KEY`.
- Set `SESSION_COOKIE_SECURE=1` when using HTTPS.
- For a production deployment, add rate limiting and account lockout controls.
- Use a production WSGI server rather than Flask's development server.
